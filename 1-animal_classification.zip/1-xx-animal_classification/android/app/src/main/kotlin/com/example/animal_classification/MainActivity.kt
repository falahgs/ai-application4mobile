package com.example.animal_classification

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
