package com.accident_detection

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
