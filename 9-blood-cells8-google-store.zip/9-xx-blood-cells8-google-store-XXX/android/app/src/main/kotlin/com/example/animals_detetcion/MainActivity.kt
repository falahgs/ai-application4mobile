package com.blood_cells_falahgs_detection

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
